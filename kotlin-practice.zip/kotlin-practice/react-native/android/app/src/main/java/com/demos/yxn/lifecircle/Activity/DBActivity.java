package com.demos.kotlin.Activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by YXN on 2018/7/10.
 */

public class DBActivity extends AppCompatActivity {
    
}

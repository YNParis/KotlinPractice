package com.demos.kotlin.views

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.demos.kotlin.R

class TouchableBallActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_touchable_ball)
  }
}

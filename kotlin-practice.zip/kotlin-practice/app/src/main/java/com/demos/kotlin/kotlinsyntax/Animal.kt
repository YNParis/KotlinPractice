package com.demos.kotlin.kotlinsyntax

/**
 * Created by YXN on 2018/10/18.
 */
open class Animal {
    open fun eat(){
        println("Animal can eat.")
    }

    open fun jump(){
        println("Animal can jump.")
    }
}
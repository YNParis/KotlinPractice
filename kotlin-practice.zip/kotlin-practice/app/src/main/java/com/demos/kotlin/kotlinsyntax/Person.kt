package com.demos.kotlin.kotlinsyntax

/**
 * Created by YXN on 2018/10/18.
 */
data class Person(var name: String, var age: Int) {
    inner class Man {
        fun hobby() {

        }

    }
}
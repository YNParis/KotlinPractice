#include <stdio.h>
#include <string.h>
#include <memory.h>

int q_ap808_hello(double i_lon, double i_lat, int o_buf_len, char *o_buf);
